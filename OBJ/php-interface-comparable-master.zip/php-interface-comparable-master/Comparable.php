<?php

interface Comparable
{
    public function compareTo($objTwo);
}