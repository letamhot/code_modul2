Luyện tập thiết kế và triển khai interface.
